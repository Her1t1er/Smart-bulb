#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>

const char* ssid = "MUGISHA Patrick";
const char* password = "happy@123";

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);

// Set LED GPIO
const int ledPin = 2;
const int ledpin1 = 4;

// Stores LED state
String ledState;
String ledState1;

// Initialize LittleFS
void initFS() {
  if (!LittleFS.begin()) {
    Serial.println("An error has occurred while mounting LittleFS");
  }
  else {
    Serial.println("LittleFS mounted successfully");
  }
}

void initWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi ..");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print('.');
    delay(1000);
  }
  Serial.println(WiFi.localIP());
}

// Showing the state of a lamp
String processor(const String& var) {
  if(var == "STATE") {
    if(!digitalRead(ledPin)) {
      ledState = "OFF";
    }
    else {
      ledState = "ON";
    }
    return ledState;
  }
  if(var == "STATE1") {
    if(!digitalRead(ledpin1)) {
      ledState1 = "OFF";
    }
    else {
      ledState1 = "ON";
    }
    return ledState1;
  }
  return String();
}

void setup() {
  // Serial port for debugging purposes
  Serial.begin(115200);
  initWiFi();
  initFS();
  
  // Set GPIO as an OUTPUT
  pinMode(2, OUTPUT);
  pinMode(4, OUTPUT);

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/index.html", "text/html",false, processor);
  });

  server.serveStatic("/", LittleFS, "/");

    // Route to set GPIO state to HIGH (inverted logic for ESP8266)
  server.on("/on", HTTP_GET, [](AsyncWebServerRequest *request) {
    digitalWrite(ledPin, HIGH);
    request->send(LittleFS, "/index.html", "text/html", false, processor);
  }); 

  // Route to set GPIO state to LOW (inverted logic for ESP8266)
  server.on("/off", HTTP_GET, [](AsyncWebServerRequest *request) {
    digitalWrite(ledPin, LOW);
    request->send(LittleFS, "/index.html", "text/html", false, processor);
  });
  server.on("/on1", HTTP_GET, [](AsyncWebServerRequest *request) {
    digitalWrite(ledpin1, HIGH);
    request->send(LittleFS, "/index.html", "text/html", false, processor);
  }); 

  // Route to set GPIO state to LOW (inverted logic for ESP8266)
  server.on("/off1", HTTP_GET, [](AsyncWebServerRequest *request) {
    digitalWrite(ledpin1, LOW);
    request->send(LittleFS, "/index.html", "text/html", false, processor);
  });
  server.begin();
}

void loop() {

}